package com.accountable.util;

public class ConfigLoader {

}
