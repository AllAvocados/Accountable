package com.accountable.core;

import java.util.prefs.Preferences;

public class ThemePreferenceManager {
    private static final String THEME_PREF_KEY = "themePreference";
    private static final Preferences prefs = Preferences.userNodeForPackage(ThemePreferenceManager.class);

    public static void saveThemePreference(boolean isDarkMode) {
        prefs.putBoolean(THEME_PREF_KEY, isDarkMode);
    }

    public static boolean loadThemePreference() {
        return prefs.getBoolean(THEME_PREF_KEY, false); // Default to light mode
    }
}
